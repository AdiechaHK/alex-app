app.controller('FooterCtrl',
  [ 
    '$scope', 

    function($scope) {

    }
  ]
);