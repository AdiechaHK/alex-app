</head> 

<body class="home-page">
    <div id="site-url" data-url="<?=site_url()?>"></div>
