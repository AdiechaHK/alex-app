
<!DOCTYPE html>
<html lang="en" data-ng-app="app"> 
<head>
    <title>Angular App</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
    <link rel="stylesheet" href="<?=base_url('assets/plugins/bootstrap/css/bootstrap.min.css')?>">
    <!-- Plugins CSS -->    
    <link rel="stylesheet" href="<?=base_url('assets/plugins/font-awesome/css/font-awesome.css')?>">
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="<?=base_url('assets/css/styles.css')?>">
