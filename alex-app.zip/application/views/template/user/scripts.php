    <!-- Javascript -->          
<script type="text/javascript" src="<?=base_url('assets/plugins/jquery-1.12.3.min.js')?>"></script>
<script type="text/javascript" src="<?=base_url('assets/plugins/bootstrap/js/bootstrap.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/plugins/bootstrap-hover-dropdown.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular/angular.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular-route/angular-route.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular-cookies/angular-cookies.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular-translate/angular-translate.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular-translate-storage-cookie/angular-translate-storage-cookie.min.js')?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular-translate-storage-local/2.12.1/angular-translate-storage-local.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular-translate-loader-static-files/2.12.1/angular-translate-loader-static-files.min.js"></script>
<script type="text/javascript" src="<?=base_url('assets/bower_components/angular-translate-loader-url/angular-translate-loader-url.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/plugins/ui-bootstrap-tpls-2.1.3.min.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/plugins/ui-bootstrap-2.1.3.min.js')?>"></script> 

<!-- Angular application script -->
<script type="text/javascript" src="<?=base_url('assets/angular/app.js')?>"></script> 

<!-- Angular Services scripts -->
<script type="text/javascript" src="<?=base_url('assets/angular/services/NavigationService.js')?>"></script> 

<!-- Angular Controller scripts -->
<script type="text/javascript" src="<?=base_url('assets/angular/controllers/NavigationCtrl.js')?>"></script> 
<script type="text/javascript" src="<?=base_url('assets/angular/controllers/FooterCtrl.js')?>"></script> 

<!-- Extra script need to be added ! -->
<script type="text/javascript" src="<?=base_url('assets/js/main.js')?>"></script>            
