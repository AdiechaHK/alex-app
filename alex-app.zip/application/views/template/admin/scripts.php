<script type="text/javascript" src="<?=base_url('assets/plugins/jquery-1.12.3.min.js')?>"></script>
<script type="text/javascript" src="<?=base_url('assets/plugins/jquery-ui.js')?>"></script>
<script type="text/javascript" src="<?=base_url('assets/plugins/jquery.mjs.nestedSortable.js')?>"></script>
<script type="text/javascript" src="<?=base_url('assets/plugins/bootstrap/js/bootstrap.min.js')?>"></script> 
<script src="//cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
<script type="text/javascript" src="<?=base_url('assets/js/admin.js')?>"></script> 