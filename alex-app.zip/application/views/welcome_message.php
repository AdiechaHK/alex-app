<div class="container">
	<div data-ng-view></div>
</div>